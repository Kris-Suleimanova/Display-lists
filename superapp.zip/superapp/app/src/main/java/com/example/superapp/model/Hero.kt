package com.example.superapp.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Hero(
    @StringRes val name: Int,
    @DrawableRes val image: Int,
    @StringRes val description: Int
)
