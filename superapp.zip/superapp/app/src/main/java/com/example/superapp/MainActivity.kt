package com.example.superapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.superapp.model.HeroesRepository
import com.example.superapp.ui.theme.List
import com.example.superapp.ui.theme.SuperappTheme

class Main : ComponentActivity() {
    override fun onCreate(save: Bundle?) {
        super.onCreate(save)
        setContent {
            SuperappTheme {
                Surface(
                    color = MaterialTheme.colorScheme.background,
                    modifier = Modifier.fillMaxSize()

                ) {
                    SuperApp()
                }
            }
        }
    }
}

@Composable
fun SuperApp() {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar()
        }
    ) {
        val heroes = HeroesRepository.heroes
        List(heroes = heroes, contentPadding = it)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBar(modifier: Modifier = Modifier) {
    CenterAlignedTopAppBar(
        title = {
            Text(
                style = MaterialTheme.typography.displayLarge,
                text = stringResource(R.string.app_name)

            )
        },
        modifier = modifier
    )
}



@Preview(showBackground = true)
@Composable
fun SuperappPreview() {
    SuperappTheme {
        SuperApp()
    }
}


