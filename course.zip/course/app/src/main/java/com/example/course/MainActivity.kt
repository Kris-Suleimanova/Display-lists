package com.example.course

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.course.data.Data
import com.example.course.model.Topic
import com.example.course.ui.theme.CourseTheme

class Main: ComponentActivity() {
    override fun onCreate(save: Bundle?) {
        super.onCreate(save)
        setContent {
            CourseTheme {
                Surface(
                    color = Color(0xFFCCCCFF),
                    
                    modifier = Modifier.fillMaxSize()

                ) {
                    Grid(
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun Grid(modifier: Modifier = Modifier) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),

        verticalArrangement = Arrangement.spacedBy(9.dp),

        horizontalArrangement = Arrangement.spacedBy(9.dp),
        
        modifier = modifier
    ) {


        items(Data.topics) { topic ->
            Card(topic)
        }
    }
}

@Composable
fun Card(topic: Topic, modifier: Modifier = Modifier) {
    Card {
        Row {
            Box {
                Image(
                    painter = painterResource(topic.imageRes),
                    contentDescription = stringResource(R.string.topic),
                    modifier = modifier.size(width = 60.dp, height = 60.dp),
                )
            }

            Column(
                modifier = Modifier.padding(start = 17.dp, top = 17.dp, end = 17.dp)
            ) {
                Text(
                    text = stringResource(topic.name),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 9.dp)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        contentDescription = stringResource(R.string.grain),
                        tint = Color(0xFF808080),
                        painter = painterResource(R.drawable.ic_grain)

                    )
                    Text(
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(start = 9.dp),
                        text = topic.availableCourses.toString()

                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun Course() {
    CourseTheme {
        val t = Data.topics[6]
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()

        ) {
            Card(t)
        }
    }
}